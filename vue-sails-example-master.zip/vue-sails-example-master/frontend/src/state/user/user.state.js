export default {
  user: {
    id: '',
    name: '',
    password: ''
  }
}
