export default {
  product: {
    title: '',
    description: '',
    price: null,
    meta: {
      isVisibleProductPatch: false
    }
  }
}
