export default {
  SET_PRODUCTS (state, products) {
    state.products = products
  }
}
