export default {
  products: {}
}
