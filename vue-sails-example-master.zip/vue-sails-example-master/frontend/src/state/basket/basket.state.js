export default {
  basket: {
    products: []
  }
}
